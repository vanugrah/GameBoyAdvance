#ifndef LOSE_BITMAP_H
#define LOSE_BITMAP_H
extern const unsigned short lose[38400];
#define LOSE_WIDTH 240
#define LOSE_HEIGHT 160
#endif