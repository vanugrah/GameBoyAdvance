#ifndef INSTRUCTION2_BITMAP_H
#define INSTRUCTION2_BITMAP_H
extern const unsigned short instruction2[38400];
#define INSTRUCTION2_WIDTH 240
#define INSTRUCTION2_HEIGHT 160
#endif