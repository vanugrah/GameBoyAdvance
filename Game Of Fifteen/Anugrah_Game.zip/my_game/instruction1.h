#ifndef INSTRUCTION1_BITMAP_H
#define INSTRUCTION1_BITMAP_H
extern const unsigned short instruction1[38400];
#define INSTRUCTION1_WIDTH 240
#define INSTRUCTION1_HEIGHT 160
#endif