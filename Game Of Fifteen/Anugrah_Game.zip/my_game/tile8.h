#ifndef TILE8_BITMAP_H
#define TILE8_BITMAP_H
extern const unsigned short tile8[1681];
#define TILE8_WIDTH 41
#define TILE8_HEIGHT 41
#endif