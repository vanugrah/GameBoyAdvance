#ifndef TILE1_BITMAP_H
#define TILE1_BITMAP_H
extern const unsigned short tile1[1681];
#define TILE1_WIDTH 41
#define TILE1_HEIGHT 41
#endif