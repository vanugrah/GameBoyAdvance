#ifndef TILE7_BITMAP_H
#define TILE7_BITMAP_H
extern const unsigned short tile7[1681];
#define TILE7_WIDTH 41
#define TILE7_HEIGHT 41
#endif