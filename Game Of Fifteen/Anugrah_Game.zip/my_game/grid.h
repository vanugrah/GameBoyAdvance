#ifndef GRID_BITMAP_H
#define GRID_BITMAP_H
extern const unsigned short grid[38400];
#define GRID_WIDTH 240
#define GRID_HEIGHT 160
#endif