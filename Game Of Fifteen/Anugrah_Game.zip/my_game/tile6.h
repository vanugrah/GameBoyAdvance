#ifndef TILE6_BITMAP_H
#define TILE6_BITMAP_H
extern const unsigned short tile6[1681];
#define TILE6_WIDTH 41
#define TILE6_HEIGHT 41
#endif