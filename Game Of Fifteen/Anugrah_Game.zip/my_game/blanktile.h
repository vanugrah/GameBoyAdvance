#ifndef BLANKTILE_BITMAP_H
#define BLANKTILE_BITMAP_H
extern const unsigned short blanktile[1681];
#define BLANKTILE_WIDTH 41
#define BLANKTILE_HEIGHT 41
#endif