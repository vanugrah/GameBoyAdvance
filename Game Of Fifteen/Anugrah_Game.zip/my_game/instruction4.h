#ifndef INSTRUCTION4_BITMAP_H
#define INSTRUCTION4_BITMAP_H
extern const unsigned short instruction4[38400];
#define INSTRUCTION4_WIDTH 240
#define INSTRUCTION4_HEIGHT 160
#endif