#ifndef TILE4_BITMAP_H
#define TILE4_BITMAP_H
extern const unsigned short tile4[1681];
#define TILE4_WIDTH 41
#define TILE4_HEIGHT 41
#endif