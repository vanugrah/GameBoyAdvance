#ifndef TILE3_BITMAP_H
#define TILE3_BITMAP_H
extern const unsigned short tile3[1681];
#define TILE3_WIDTH 41
#define TILE3_HEIGHT 41
#endif