#ifndef TILE2_BITMAP_H
#define TILE2_BITMAP_H
extern const unsigned short tile2[1681];
#define TILE2_WIDTH 41
#define TILE2_HEIGHT 41
#endif