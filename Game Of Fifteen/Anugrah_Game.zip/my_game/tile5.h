#ifndef TILE5_BITMAP_H
#define TILE5_BITMAP_H
extern const unsigned short tile5[1681];
#define TILE5_WIDTH 41
#define TILE5_HEIGHT 41
#endif