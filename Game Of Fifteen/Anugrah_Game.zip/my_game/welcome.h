#ifndef WELCOME_BITMAP_H
#define WELCOME_BITMAP_H
extern const unsigned short welcome[38400];
#define WELCOME_WIDTH 240
#define WELCOME_HEIGHT 160
#endif