#ifndef INSTRUCTION3_BITMAP_H
#define INSTRUCTION3_BITMAP_H
extern const unsigned short instruction3[38400];
#define INSTRUCTION3_WIDTH 240
#define INSTRUCTION3_HEIGHT 160
#endif